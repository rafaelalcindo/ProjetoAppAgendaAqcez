

function onLoad() {
      document.addEventListener("deviceready", onDeviceReady, false);
}

function onDeviceReady() {
	alert('onLoad Function agenda Funcionou!');
    
}
