

function onLoad() {
      document.addEventListener("deviceready", onDeviceReady, false);
}

function onDeviceReady() {
	alert('onLoad Function agenda Funcionou!');
     var push = sessionStorage.getItem('push');

     push.on('notification', function(data) {
        alert(data.title+" Message: " +data.message);
     });

    push.on('error', function(e) {
        alert(e);
    });
}
